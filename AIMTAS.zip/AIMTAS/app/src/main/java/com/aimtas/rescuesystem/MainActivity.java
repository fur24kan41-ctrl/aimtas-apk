package com.aimtas.rescuesystem;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tvDroneStatus;
    private TextView tvSignalStrength;
    private TextView tvBattery;
    private TextView tvFlightMode;
    private TextView tvLocation;
    private TextView tvDebrisStatus;
    private TextView tvConfidence;
    private TextView tvBluetoothStatus;
    private TextView tvConnectedDevice;
    private TextView tvLogMessages;

    private Handler handler;
    private Random random;
    private int batteryLevel = 100;
    private int messageIndex = 0;
    private boolean bluetoothConnected = false;
    private boolean debrisDetected = false;

    private String[] logMessages = {
            "Sistem başlatılıyor...",
            "İHA ile bağlantı kuruluyor...",
            "Bluetooth bağlantısı kuruldu",
            "Kurtarma Telefonu - 1 bağlandı",
            "İHA'dan veri alınıyor...",
            "Arama bölgesi taranıyor...",
            "Termal kamera aktif",
            "Görüntü analizi devam ediyor...",
            "UYARI: Enkaz tespit edildi!",
            "Enkaz konumu: 39.7491° K, 39.4943° D",
            "Güven oranı: %93",
            "Koordinatlar merkeze gönderildi",
            "Kurtarma ekibi bilgilendirildi",
            "Kurtarma ekibi yönlendirildi",
            "Canlı sinyal tespit edildi",
            "Ekip olay yerine ulaştı",
            "Tarama devam ediyor..."
    };

    private String[] signalLevels = {"Güçlü", "Orta", "Zayıf"};
    private int[] signalColors = {0xFF4CAF50, 0xFFFF9800, 0xFFF44336};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        random = new Random();
        handler = new Handler(Looper.getMainLooper());

        startSimulation();
    }

    private void initializeViews() {
        tvDroneStatus = findViewById(R.id.tvDroneStatus);
        tvSignalStrength = findViewById(R.id.tvSignalStrength);
        tvBattery = findViewById(R.id.tvBattery);
        tvFlightMode = findViewById(R.id.tvFlightMode);
        tvLocation = findViewById(R.id.tvLocation);
        tvDebrisStatus = findViewById(R.id.tvDebrisStatus);
        tvConfidence = findViewById(R.id.tvConfidence);
        tvBluetoothStatus = findViewById(R.id.tvBluetoothStatus);
        tvConnectedDevice = findViewById(R.id.tvConnectedDevice);
        tvLogMessages = findViewById(R.id.tvLogMessages);
    }

    private void startSimulation() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateSimulation();
                handler.postDelayed(this, 3000);
            }
        }, 1000);
    }

    private void updateSimulation() {
        updateBluetooth();
        updateBattery();
        updateSignal();
        updateDebrisStatus();
        addLogMessage();
    }

    private void updateBluetooth() {
        if (messageIndex >= 2 && !bluetoothConnected) {
            bluetoothConnected = true;
            tvBluetoothStatus.setText("Bağlı");
            tvBluetoothStatus.setTextColor(0xFF4CAF50);
            tvConnectedDevice.setText("Kurtarma Telefonu - 1");
            tvConnectedDevice.setTextColor(0xFF333333);
        }
    }

    private void updateBattery() {
        if (batteryLevel > 45) {
            batteryLevel -= random.nextInt(3) + 1;
            tvBattery.setText("%" + batteryLevel);

            if (batteryLevel > 60) {
                tvBattery.setTextColor(0xFF4CAF50);
            } else if (batteryLevel > 30) {
                tvBattery.setTextColor(0xFFFF9800);
            } else {
                tvBattery.setTextColor(0xFFF44336);
            }
        }
    }

    private void updateSignal() {
        int signalIndex = random.nextInt(3);
        if (bluetoothConnected) {
            if (random.nextInt(10) < 7) {
                signalIndex = 0;
            } else if (random.nextInt(10) < 8) {
                signalIndex = 1;
            }
        }

        tvSignalStrength.setText(signalLevels[signalIndex]);
        tvSignalStrength.setTextColor(signalColors[signalIndex]);
    }

    private void updateDebrisStatus() {
        if (messageIndex >= 8 && !debrisDetected) {
            debrisDetected = true;
            tvDebrisStatus.setText("Tespit Edildi");
            tvDebrisStatus.setTextColor(0xFFD32F2F);
            tvConfidence.setText("%93");
            tvConfidence.setTextColor(0xFFD32F2F);
        }
    }

    private void addLogMessage() {
        if (messageIndex < logMessages.length) {
            String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
            String newMessage = "[" + timestamp + "] " + logMessages[messageIndex] + "\n";

            tvLogMessages.append(newMessage);
            messageIndex++;

            final TextView finalTv = tvLogMessages;
            handler.post(new Runnable() {
                @Override
                public void run() {
                    int scrollAmount = finalTv.getLayout().getLineTop(finalTv.getLineCount()) - finalTv.getHeight();
                    if (scrollAmount > 0) {
                        finalTv.scrollTo(0, scrollAmount);
                    }
                }
            });
        } else {
            String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
            String[] repeatMessages = {
                    "Tarama devam ediyor...",
                    "Bölge izleniyor...",
                    "İHA aktif görevde...",
                    "Sinyal kalitesi: Normal"
            };
            String randomMsg = repeatMessages[random.nextInt(repeatMessages.length)];
            String newMessage = "[" + timestamp + "] " + randomMsg + "\n";
            tvLogMessages.append(newMessage);

            final TextView finalTv = tvLogMessages;
            handler.post(new Runnable() {
                @Override
                public void run() {
                    int scrollAmount = finalTv.getLayout().getLineTop(finalTv.getLineCount()) - finalTv.getHeight();
                    if (scrollAmount > 0) {
                        finalTv.scrollTo(0, scrollAmount);
                    }
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }
}
